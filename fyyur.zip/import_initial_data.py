from app import Venue, Artist, Show, db
#  ----------------------------------------------------------------
#  Venues
#  ----------------------------------------------------------------
venues_data = [{
    "id": 1,
    "city": "San Francisco",
    "state": "CA",
    "name": "The Musical Hop",
    "address": "1015 Folsom Street",
    "phone": "123-123-1234",
    "website": "https://github.com/financecompanies",
    "facebook_link": "#",
    "genres": ["Jazz", "Reggae", "Swing", "Classical", "Folk"],
    "seeking_talent": True,
    "seeking_description": "We are on the lookout for a local artist to play every two weeks. Please call us.",
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4",
}, {
    "id": 3,
    "city": "San Francisco",
    "state": "CA",
    "name": "Park Square Live Music & Coffee",
    "genres": ["Rock n Roll", "Jazz", "Classical", "Folk"],
    "address": "34 Whiskey Moore Ave",
    "phone": "415-000-1234",
    "website": "https://github.com/financecompanies",
    "facebook_link": "#",
    "seeking_talent": False,
    "seeking_description": None,
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4",
}, {
    "id": 2,
    "city": "New York",
    "state": "NY",
    "name": "The Dueling Pianos Bar",
    "genres": ["Classical", "R&B", "Hip-Hop"],
    "address": "335 Delancey Street",
    "phone": "914-003-1132",
    "website": "https://github.com/financecompanies",
    "facebook_link": "#",
    "seeking_talent": False,
    "seeking_description": None,
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4"
}]

#  ----------------------------------------------------------------
#  Artists
#  ----------------------------------------------------------------
artists_data = [{
    "id": 4,
    "name": "Guns N Petals",
    "genres": ["Rock n Roll"],
    "city": "San Francisco",
    "state": "CA",
    "phone": "326-123-5000",
    "website": "https://github.com/financecompanies",
    "facebook_link": "#",
    "seeking_venue": True,
    "seeking_description": "Looking for shows to perform at in the San Francisco Bay Area!",
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4"
    }, {
    "id": 5,
    "name": "Matt Quevedo",
    "genres": ["Jazz"],
    "city": "New York",
    "state": "NY",
    "phone": "300-400-5000",
    "facebook_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4",
    "seeking_venue": False,
    "seeking_description": None,
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4"
    }, {
    "id": 6,
    "name": "The Wild Sax Band",
    "genres": ["Jazz", "Classical"],
    "city": "San Francisco",
    "state": "CA",
    "phone": "432-325-5432",
    "seeking_venue": False,
    "seeking_description": None,
    "image_link": "https://avatars1.githubusercontent.com/u/56381023?s=400&u=4d0799085ae6b87546a1f7f9816ea4552682fd32&v=4"
}]

#  ----------------------------------------------------------------
#  Shows
#  ----------------------------------------------------------------
shows_data = [{
    "venue_id": 1,
    "artist_id": 4,
    "start_time": "2019-05-21T21:30:00.000Z"
    }, {
    "venue_id": 3,
    "artist_id": 5,
    "start_time": "2019-06-15T23:00:00.000Z"
    }, {
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2035-04-01T20:00:00.000Z"
    }, {
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2035-04-08T20:00:00.000Z"
    }, {
    "venue_id": 3,
    "artist_id": 6,
    "start_time": "2035-04-15T20:00:00.000Z"
    }]


#  ----------------------------------------------------------------
#  Load Data into DB
#  ----------------------------------------------------------------
for v in venues_data:
    venue = Venue(id=v["id"],
                  name=v["name"])
    for key, value in v.items():
        setattr(venue, key, value)
    db.session.add(venue)
    db.session.commit()

for a in artists_data:
    artist = Artist(id=a["id"],
                    name=a["name"])
    for key, value in a.items():
        setattr(artist, key, value)
    db.session.add(artist)
    db.session.commit()

for s in shows_data:
    show = Show(venue_id=s["venue_id"],
                artist_id=s["artist_id"],
                start_time=s["start_time"])
    db.session.add(show)
    db.session.commit()